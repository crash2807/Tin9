var express = require('express');
var router = express.Router();
var bodyParser = require("body-parser");
var app = express();
var path = require('path');

var bodyParser = require('body-parser');
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));

app.set("port", process.env.PORT || 3500);
app.use(express.static("public"));

let sumadanych = [];

app.get("/hello", function (req,res) {
let hello = "hello world";
res.json(hello);
});

app.get("/form", function (req,res) {
  res.sendFile(path.join(__dirname + '/site/form.html'));
});

app.post("/formdata", function (req,res){
  //console.log(req)
  let ret = '<label> imie: '+req.body.imie+'</label></br>';
  ret += '<label> nazwisko: '+req.body.nazwisko+'</label></br>';
  ret += '<label> nr indeksu: '+req.body.nrInd+'</label>';
  res.send(ret);
});

app.post("/jsondata", (req,res)=>{// struktura jsona do zapytania: {"imie":"Jan", "nazwisko":"Kowalski", "ulica":"poziomkowa"}
  console.log(req.body);
  let ret = '<label> imie: '+req.body.imie+'</label></br>';
  ret += '<label> nazwisko: '+req.body.nazwisko+'</label></br>';
  ret += '<label> ulica: '+req.body.ulica+'</label>';
  res.send(ret);
});

/* GET home page. */
//router.get('/', function(req, res, next) {
//  res.render('index', { title: 'Express' });
//});
var server = app.listen(app.get("port"), function() {
  console.log("Server up: http://localhost:" + app.get("port"));
});
app.post("/formdata", function (req, res) {
  let dane = {
     imie: req.body.imie,
    nazwisko: req.body.nazwisko,
    nrInd: req.body.nrInd,
  };
  console.log(dane);
  sumadanych.push(dane);

});
module.exports = router;
